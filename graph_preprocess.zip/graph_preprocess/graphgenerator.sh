python graphgenerator.py \
    -javafile '../AST_JAVA_DIFF/' \
    -savepair 'graph.pdf'