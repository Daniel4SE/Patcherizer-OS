python Parser2Graph.py \
    -javafile 'c.txt' \
    -savefile 'graphtest.png' \
    -layout 'kamada_kawai_layout' \
    -drawcompute 'draw' \
    -savepair 'graphtest.pkl'